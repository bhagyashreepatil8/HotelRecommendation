package org.hotel.rec.model;

public class ArticalModel 
{
  private int aid;
  private String aname;
  private int cityid;
  private int areaid;
  
  public ArticalModel()
  {
	  
  }
  public ArticalModel(int aid,String aname,int cityid,int areaid)
  {
	  this.aid=aid;
	  this.aname=aname;
	  this.cityid=cityid;
	  this.areaid=areaid;
  }
  
  public int getAid() {
	return aid;
}
public void setAid(int aid) {
	this.aid = aid;
}
public String getAname() {
	return aname;
}
public void setAname(String aname) {
	this.aname = aname;
}
public int getCityid() {
	return cityid;
}
public void setCityid(int cityid) {
	this.cityid = cityid;
}
public int getAreaid() {
	return areaid;
}
public void setAreaid(int areaid) {
	this.areaid = areaid;
}
public int getAvgrating() {
	return avgrating;
}
public void setAvgrating(int avgrating) {
	this.avgrating = avgrating;
}
private int avgrating;
}
