package org.hotel.rec.repository;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hotel.rec.config.DBHelper;
import org.hotel.rec.model.AdminUserModel;

public class AdminUserRepositiory extends DBHelper
{ 
	private List<AdminUserModel> list=new ArrayList<AdminUserModel>();
  public boolean isAddUSer(AdminUserModel model)
  {
	  try
	  {
		  stmt=conn.prepareStatement("insert into user values('0',?,?,?,?,?)");
		  stmt.setString(1, model.getAdminname());
		  stmt.setString(2, model.getEmail());
		  stmt.setString(3, model.getMobilenum());
		  stmt.setString(4, model.getPassword());
		  stmt.setString(5, model.getStatus());
		  int value=stmt.executeUpdate();
		  return value>0?true:false;
	  }
	  catch(Exception ex)
	  {
		  System.out.println("error is "+ex);
		  return false;
	  }
	  
  }

public boolean authenticatoruser(String email, String password) {
	 int value=0;
	   try {
		stmt=conn.prepareStatement("select email,password from user where email=? and password=?");
		  stmt.setString(1, email);
		  stmt.setString(2, password);
		  rs=stmt.executeQuery();
		  while(rs.next()) {
			  String emil;
			  String pass;
			  emil=rs.getString(1);
			  pass=rs.getString(2);
	          
			  if(emil.equals(email) && pass.equals(pass)) {
				  value=1;
			  }
		  }
		 
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	   
	return value>0?true:false;
}

public List<AdminUserModel> getAllUser()
{  
	  try
	  {
		 stmt=conn.prepareStatement("select *from user");
		 rs=stmt.executeQuery();
		 while(rs.next())
		 {
			 AdminUserModel model=new AdminUserModel();
			 model.setAdminid(rs.getInt(1));
			 model.setAdminname(rs.getString(2));
			 model.setEmail(rs.getString(3));
			 model.setMobilenum(rs.getString(4));
			 model.setPassword(rs.getString(5));
			 model.setStatus(rs.getString(6));
			 list.add(model);
		 }
		 return list.size()>0?list:null;
	  }
	  catch(Exception ex)
	  {
		  System.out.println("error is "+ex);
		  return null;
	  }
	 
}

public boolean getUpdateStatus(String mobile,String name)
{
int value=0;
try
{
	stmt=conn.prepareStatement("update user set adminName=? where mobilenum=?");
	stmt.setString(1, name);
	stmt.setString(2, mobile);
	
	 value=stmt.executeUpdate();
	 if(value>0)
	 {
		 System.out.println("user updated successfully");
	 }
	 else
	 {
		 System.out.println("no user found with a given mobile num");
	 }
}
catch(Exception ex)
{
	System.out.println("error is "+ex);
}
return value>0?true:false;
}

}
